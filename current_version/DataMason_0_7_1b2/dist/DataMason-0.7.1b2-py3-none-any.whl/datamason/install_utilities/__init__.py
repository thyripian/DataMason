from .install_polyglot import install_polyglot_func
from .install_models import install_models